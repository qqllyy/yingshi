<?php include 'head.php';$yl='active';?>
<title>综合视频-<?php echo $mkcms_seoname;?></title>
<meta name="keywords" content="娱乐,<?php echo $mkcms_keywords;?>">
<meta name="description" content="<?php echo $mkcms_description;?>">
</head>
<body>
<?php include 'header.php';?>
<div class="container">
	<div class="row">
		<?php echo get_ad(16)?>
		<div class="stui-pannel stui-pannel-bg clearfix">
			<div class="stui-pannel-box">
				<div class="stui-pannel_hd">
					<div class="stui-pannel__head active bottom-line clearfix">
					<h3 class="title"><img src="/template/jingpin/img/icon_27.png">综合视频</h3>
					</div>
				</div><!-- 筛选 -->
				<ul class="stui-screen__list type-slide clearfix up-ul1">
				<li><span class="text-muted">按类型</span> </li>
				<li><a href="./yule_c_86_s_1_d_1_p_1.html" >全部</a></li>
				<li><a href="./yule_c_86_s_6_d_1_p_2.html">娱乐</a></li>
				<li><a href="./yule_c_98_s_6_d_1_p_1.html">体育</a></li>
				<li><a href="./yule_c_87_s_6_d_1_p_1.html">教育</a></li>
				<li><a href="./yule_c_99_s_6_d_1_p_1.html">游戏</a></li>
				<li><a href="./yule_c_178_s_6_d_1_p_1.htm">文化</a></li>
				<li><a href="./yule_c_98_g_健身_a_6_d_1_p_1.html">健身</a></li>
				<li><a href="./fun_c_94_d_1_s_1_p_1.html">搞笑</a></li>
				<li><a href="./yule_c_98_g_广场舞_s_6_d_1_p_1.html">广场舞</a></li>
				</ul><!-- end 筛选 -->
			</div>
			<div class="stui-pannel_bd">
				<ul class="stui-vodlist clearfix">
					<?php
					if (empty($_GET['m'])) {
						$html = "http://list.youku.com/category/show/c_86_s_1_d_1_p_1.html";
					} else {
						$html = "http://list.youku.com/category/show/" . $_GET["m"];
					}
					$rurl = file_get_contents($html);
					$vname = "#<li class=\"yk-col4 mr1\"><div class=\"yk-pack pack-film\"><div class=\"p-thumb\"><a href=\"(.*?)\" title=\"(.*?)\" target=\"_blank\"></a><i class=\"bg\"></i><img class=\"quic\" _src=\"(.*?)\" src=\"(.*?)\" alt=\"(.*?)\" /></div><ul class=\"p-info pos-bottom\"><li class=\"status hover-hide\"><span class=\"p-time \"><i class=\"ibg\"></i><span>(.*?)</span></span></li></ul><ul class=\"info-list\"><li class=\"title\"><a href=\"(.*?)\" title=\"(.*?)\" target=\"_blank\">(.*?)</a></li><li>(.*?)</li></ul></div></li>#";
					preg_match_all($vname, $rurl, $xarr);
					$xbflist = $xarr[1];
					$xname = $xarr[2];
					$ximg = $xarr[4];
					$shijian = $xarr[6];
					$bofang = $xarr[10];
					foreach ($xname as $key => $xvau) {
						$do = $xbflist[$key];
						$do1 = base64_encode($do);
						$dd="./fplay/";
						$html2=".html";
						$ccb = $dd.$do1.$html2;
					?>
					<li class='col-md-6 col-sm-4 col-xs-3'>
					<div class='stui-vodlist__box'>
					<a class='stui-vodlist__thumb lazyload' href='<?php echo $ccb;?>' title='<?php echo $xname[$key];?>' data-original='<?php echo $ximg[$key];?>'>
					<span class='play hidden-xs'></span>
					<span class='pic-tag pic-tag-b'><?php echo $shijian[$key];?></span></a>
					<div class='stui-vodlist__detail'>
					<h4 class='title text-overflow'><a href='<?php echo $ccb;?>' title='<?php echo $xname[$key];?>' title='<?php echo $xname[$key];?>'><?php echo $xname[$key];?></a></h4>
					<p class='text text-overflow text-muted hidden-xs'><?php echo $bofang[$key];?></p>
					</div>
					</div>
					</li><?php } ?>
				</ul>
			</div>
		</div>
	</div>
</div>
<ul class="stui-page text-center cleafix">
	<?php
	$curl = curl_init();
	curl_setopt($curl, CURLOPT_URL, $html);
	curl_setopt($curl, CURLOPT_HEADER, 1);
	curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
	$response = curl_exec($curl);
	curl_close($curl);
	$response = strstr($response, "<div class=\"yk-pager\">");
	$response = strstr($response, "<div class=\"vault-banner", true);
	$response = str_replace("<div class=\"yk-pager\">", "", $response);
	$response = str_replace("</div>", "", $response);
	$response = str_replace("<span>", "<a>", $response);
	$response = str_replace("<ul class=\"yk-pages\">", "<div monitor-desc='分页' id='js-ew-page' data-block='js-ew-page'  class='ew-page'>", $response);
	$response = str_replace("</ul>", "</div>", $response);
	$response = str_replace("<span class=\"current\">", "<a class=\"on\">", $response);
	$response = str_replace("<li class=\"current\">", "<li class=\"active\">", $response);
	$response = str_replace("</span>", "</a>", $response);
	$response = str_replace("//list.youku.com/category/show/", "yule_", $response);
	$response = str_replace("<a class=\"next\" title=\"下一页\">", "", $response);
	$response = str_replace("上一页", "<", $response);
	$response = str_replace("下一页", ">", $response);
	echo $response;
?>
</ul>
<?php  include 'footer.php';?>