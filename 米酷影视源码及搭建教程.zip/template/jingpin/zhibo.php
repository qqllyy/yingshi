<?php  include 'head.php';$zb='active';$fl='active';?>
<title>电视直播-<?php echo $mkcms_seoname;?></title>
<meta name="keywords" content="电视直播,湖南卫视,<?php echo $mkcms_keywords;?>">
<meta name="description" content="<?php echo $mkcms_description;?>">
<link href="/template/jingpin/skin/css/app.css" rel="stylesheet" type="text/css" />
<script src="/template/jingpin/skin/js/jquery.min.js"></script>
<script src="/template/jingpin/skin/js/common.js"></script>
<style type="text/css">
img{max-width:100%;background-size:cover;margin-bottom: -5px;}
</style>
</head>
<body>
<?php include 'header.php'; ?>
<div class="container">
	<div class="row">
		<?php echo get_ad(20)?>
		<div class="stui-pannel stui-pannel-bg clearfix">
			<div class="stui-pannel-box">
				<div class="stui-pannel_hd">
					<div class="stui-pannel__head active bottom-line clearfix">
					<h3 class="title"><img src="/template/jingpin/img/icon_27.png">电视直播</h3>
					</div>
				</div>
			</div>
			<div class="stui-pannel_bd">
				<div class="icon">
					<div class="container izb">
						<nav class="zb-nav"><a href="javascript:;" class="taba cur">央视频道</a><a href="javascript:;" class="taba">卫视频道</a><a href="javascript:;" class="taba">影视频道</a><a href="javascript:;" class="taba">明星专辑</a></nav>
						<div class="zb-con">
						<ul class="zb-list">
							<li><a href="javascript:;" data-url="http://t.cn/RpFPVsE"><b><img src="/template/jingpin/skin/images/c1.png" /></b><span>CCTV 1</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFPN6v"><b><img src="/template/jingpin/skin/images/c2.png"></b><span>CCTV 2</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RXQY4TK"><b><img src="/template/jingpin/skin/images/c3.png"></b><span>CCTV 3</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFPrgx"><b><img src="/template/jingpin/skin/images/c4.png"></b><span>CCTV 4</span></a></li>
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://223.110.245.141/ott.js.chinamobile.com/PLTV/3/224/3221225604/index.m3u8"><b><img src="/template/jingpin/skin/images/c5.png"></b><span>CCTV 5</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFhJLn"><b><img src="/template/jingpin/skin/images/c6.png"></b><span>CCTV 6</span></a></li>
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://183.207.248.8:80/PLTV/3/224/3221225546/index.m3u8"><b><img src="/template/jingpin/skin/images/c7.png"></b><span>CCTV 7</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFhSzl"><b><img src="/template/jingpin/skin/images/c8.png"></b><span>CCTV 8</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFhwWm"><b><img src="/template/jingpin/skin/images/c9.png"></b><span>CCTV 9</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFh2KW"><b><img src="/template/jingpin/skin/images/c10.png"></b><span>CCTV 10</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFhyzk"><b><img src="/template/jingpin/skin/images/c11.png"></b><span>CCTV 11</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFhU8c"><b><img src="/template/jingpin/skin/images/c12.png"></b><span>CCTV 12</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFhb9z"><b><img src="/template/jingpin/skin/images/c13.png"></b><span>CCTV 13</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFhqUF"><b><img src="/template/jingpin/skin/images/c14.png"></b><span>CCTV 14</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFhtUX"><b><img src="/template/jingpin/skin/images/c15.png"></b><span>CCTV 15</span></a></li>
						</ul>
						<ul class="zb-list hide">
							<li><a href="javascript:;" data-url="http://t.cn/RLQqNvg"><b><img src="/template/jingpin/skin/images/hn.png" /></b><span>湖南卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/R6Jrh0y"><b><img src="/template/jingpin/skin/images/zj.png" /></b><span>浙江卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RVylk9M"><b><img src="/template/jingpin/skin/images/js.png" /></b><span>江苏卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RLcRIHw"><b><img src="/template/jingpin/skin/images/df.png" /></b><span>东方卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFzrnr"><b><img src="/template/jingpin/skin/images/bj.png" /></b><span>北京卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFzDXB"><b><img src="/template/jingpin/skin/images/ah.png" /></b><span>安徽卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZvZn"><b><img src="/template/jingpin/skin/images/sd.png" /></b><span>山东卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZL4M"><b><img src="/template/jingpin/skin/images/ha.png" /></b><span>河南卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZqm8"><b><img src="/template/jingpin/skin/images/jx.png" /></b><span>江西卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZVXT"><b><img src="/template/jingpin/skin/images/hlj.png" /></b><span>黑龙江卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZxtl"><b><img src="/template/jingpin/skin/images/gd.png" /></b><span>广东卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZXVc"><b><img src="/template/jingpin/skin/images/tj.png" /></b><span>天津卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZNi6"><b><img src="/template/jingpin/skin/images/hub.png" /></b><span>湖北卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZWZA"><b><img src="/template/jingpin/skin/images/heb.png" /></b><span>河北卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZYop"><b><img src="/template/jingpin/skin/images/cq.png" /></b><span>重庆卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZQHu"><b><img src="/template/jingpin/skin/images/dn.png" /></b><span>东南卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZEC4"><b><img src="/template/jingpin/skin/images/sx1.png" /></b><span>山西卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZuWA"><b><img src="/template/jingpin/skin/images/gx.png" /></b><span>广西卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZBpR"><b><img src="/template/jingpin/skin/images/gz.png" /></b><span>贵州卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFZgD6"><b><img src="/template/jingpin/skin/images/sz.png" /></b><span>深圳卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFwP3U"><b><img src="/template/jingpin/skin/images/jl.png" /></b><span>吉林卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFwZUV"><b><img src="/template/jingpin/skin/images/ln.png" /></b><span>辽宁卫视</span></a></li>
							<li><a href="javascript:;" data-url="http://t.cn/RpFw2zU"><b><img src="/template/jingpin/skin/images/sc.png" /></b><span>四川卫视</span></a></li>
						</ul>
						<ul class="zb-list hide">
							<li><a href="javascript:;" data-url="http://t.cn/RpFw4ZA"><b><img src="/template/jingpin/skin/images/chc.png" /></b></a></li>
						<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://tx.hls.huya.com/huyalive/29106097-2689286606-11550398022340837376-2789274544-10057-A-0-1.m3u8"><b><img src="/template/jingpin/skin/images/ss.png" /></b></a></li>
						<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://ott.fj.chinamobile.com/PLTV/88888888/224/3221225879/index.m3u8"><b><img src="/template/jingpin/skin/images/dz.png" /></b></a></li>
						<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://aldirect.hls.huya.com/huyalive/28466698-2689656864-11551988268341919744-2847699194-10057-A-0-1_1200.m3u8"><b><img src="/template/jingpin/skin/images/kh.png" /></b></a></li>
						<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://tx.hls.huya.com/huyalive/30765679-2523417522-10837995731143360512-2777068634-10057-A-0-1.m3u8"><b><img src="/template/jingpin/skin/images/ghz.png" /></b></a></li>
						</ul>
						<ul class="zb-list hide">
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://tx.hls.huya.com/huyalive/30765679-2554414705-10971127618396487680-3048991636-10057-A-0-1.m3u8"><b><img src="/template/jingpin/skin/images/wj.png" /></b><span>吴京</span></a></li>
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://aldirect.hls.huya.com/huyalive/94525224-2460685313-10568562945082523648-2789274524-10057-A-0-1_1200.m3u8"><b><img src="/template/jingpin/skin/images/zxc.png" /></b><span>周星驰</span></a></li>
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://aldirect.hls.huya.com/huyalive/94525224-2467341872-10597152648291418112-2789274550-10057-A-0-1_1200.m3u8"><b><img src="/template/jingpin/skin/images/ldh.png" /></b><span>刘德华</span></a></li>
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://tx.hls.huya.com/huyalive/94525224-2460685774-10568564925062447104-2789253840-10057-A-0-1.m3u8"><b><img src="/template/jingpin/skin/images/zrf.png" /></b><span>周润发</span></a></li>
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://aldirect.hls.huya.com/huyalive/94525224-2460685722-10568564701724147712-2789253838-10057-A-0-1_1200.m3u8"><b><img src="/template/jingpin/skin/images/cl.png" /></b><span>成龙</span></a></li>
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://tx.hls.huya.com/huyalive/30765679-2689675828-11552069718101721088-3048991626-10057-A-0-1.m3u8"><b><img src="/template/jingpin/skin/images/xz.png" /></b><span>徐峥</span></a></li>
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://tx.hls.huya.com/huyalive/94525224-2469517548-10606497105558110208-2847699176-10057-A-0-1.m3u8"><b><img src="/template/jingpin/skin/images/lxl.png" /></b><span>李小龙</span></a></li>
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://tx.hls.huya.com/huyalive/29169025-2686219938-11537226783573147648-2847699096-10057-A-1524024759-1.m3u8"><b><img src="/template/jingpin/skin/images/zzd.png" /></b><span>甄子丹</span></a></li>
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://aldirect.hls.huya.com/huyalive/94525224-2579683592-11079656661667807232-2847687574-10057-A-0-1_1200.m3u8"><b><img src="/template/jingpin/skin/images/wj2.png" /></b><span>王晶</span></a></li>
							<li><a href="javascript:;" data-url="<?php echo $mkcms_domain;?>ck/index.php?url=http://aldirect.hls.huya.com/huyalive/29106097-2689447148-11551087544980471808-2789253872-10057-A-1525420294-1_1200.m3u8"><b><img src="/template/jingpin/skin/images/xk.png" /></b><span>徐克</span></a></li>
						</ul>
						</div>
					</div>
				</div>
<script src="/template/jingpin/skin/js/lazyload.min.js"></script>
<script src="/template/jingpin/skin/js/app.js"></script>
				<div class="zb-plays">
					<div class="zb-play"><a href="javascript:;" class="close">x</a>
						<div class="ipcon" id="ipcon">
						<iframe id="frmLive" frameborder="0" width="100%" src=""></iframe>
						</div>
					</div>
    			</div>
				<script>
				var $a = $('.zb-nav a'),
				$ul = $('.zb-con ul'),
				$alast = $('.sitenav a:last-child'),
				$abtn = $('.zb-list li a');
				$alast.addClass('cur');
				$a.click(function() {
				var $this = $(this);
				var $t = $this.index();
				$a.removeClass();
				$this.addClass('cur');
				$ul.addClass('hide').removeClass('show');
				$ul.eq($t).addClass('show');
				});
				$abtn.on('click', function(e) {
				var vurl = $(this).attr("data-url");
				var w = document.documentElement ? document.documentElement.clientWidth : document.body.clientWidth;
				$('#frmLive').attr('src', vurl);
				if (w < 767) {
				$('#frmLive').height = 260;
				} else {
				$('#frmLive').height = 600;
				};
				$('html').addClass('show');
				e.stopPropagation();
				});
				$('.zb-plays .close').on('click', function() {
				$('html').removeClass('show');
				document.getElementById('frmLive').src = '';
				})
				$('.izbs').addClass('cur');
				$('.iapp').removeClass('cur');
				</script>
			</div>
		</div>
	</div>
</div>
<?php include 'footer.php';?>