function submv(){
	var str = document.getElementById('sousuo').value;
		if (str==""||str==null){
			alert("请输入明星、MV关键词")
		}else{
			var s=$('#sousuo').val();
            s=s.replace(/\s/g,"");
			window.location.href="/mv_so_"+s+".html";

		}
}
function sub3(){
	var str = document.getElementById('searchs').value;
		if (str==""||str==null){
			alert("请输入明星名称")
		}else{
			var k= $('#mode').val();
			var s=$('#searchs').val();
                s=s.replace(/\s/g,"");
			//window.open("/"+k+"-"+s+".html", '_blank');
			//var tempwindow=window.open('_blank'); // 先打开页面
            //tempwindow.location="/"+k+"-"+s+".html";
					
			window.location.href="/"+k+"_"+s+"_dy_1.html";
		}
}