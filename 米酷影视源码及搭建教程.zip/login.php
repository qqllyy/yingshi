<?php 
include('system/inc.php');
header('location:ucenter/login.php');
?>