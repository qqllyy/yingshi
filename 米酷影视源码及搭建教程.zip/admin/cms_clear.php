<?php
include('../system/inc.php');
include('cms_check.php');
error_reporting(0);
$get = isset($_GET['clear']) ? $_GET['clear'] : '';
switch($get){
	case 'index':
	$handle = opendir('../cache/index');  
    while (($file=readdir($handle))) {            
            unlink("../cache/index/"."$file");     
    }closedir($handle);  
alert_href('清除首页缓存成功!','cms_clear.php');
break;
case 'list':
$handle = opendir('../cache/list');  
    while (($file=readdir($handle))) {            
            unlink("../cache/list/"."$file");     
    }closedir($handle);  
alert_href('清除视频列表缓存成功!','cms_clear.php');
break;
case 'top':
$handle = opendir('../cache/top');  
    while (($file=readdir($handle))) {            
            unlink("../cache/top/"."$file");     
    }closedir($handle);  
alert_href('清除影视排行缓存成功!','cms_clear.php');
break;
case 'play':
$handle = opendir('../cache/play');  
    while (($file=readdir($handle))) {            
            unlink("../cache/play/"."$file");     
    }closedir($handle);  
alert_href('清除影视播放缓存成功!','cms_clear.php');
break;
case 'like':
$handle = opendir('../cache/like');  
    while (($file=readdir($handle))) {            
            unlink("../cache/like/"."$file");     
    }closedir($handle);  
alert_href('清除猜你喜欢缓存成功!','cms_clear.php');
break;
case 'slide':
	$handle = opendir('../cache/slide');  
    while (($file=readdir($handle))) {            
            unlink("../cache/slide/"."$file");     
    }closedir($handle);  
alert_href('清除slide缓存成功!','cms_clear.php');
break;
}
?>
<?php include('inc_header.php') ?>
<script type="text/javascript">			
function clear(lb){
		$.ajax({ 
			type: "POST",  
			url: "cms_clear.php", 
			data:{"lb":lb},
			success: function(msg){ 
			$(".sxym").load(location.href+" .sxym");
			alert('清理成功');
			}
		});
}
</script>
		<!-- Start: Content -->
		<div class="container-fluid content">	
			<div class="row">
<?php include('inc_left.php') ?>
<?php include('csize.php') ?>
				<!-- Main Page -->
				<div class="main ">
					<!-- Page Header -->
					<div class="page-header">
						<div class="pull-left">
							<ol class="breadcrumb visible-sm visible-md visible-lg">								
								<li><a href="cms_welcome.php"><i class="icon fa fa-home"></i>首页</a></li>
							</ol>						
						</div>
						<div class="pull-right">
							<h2>清理缓存</h2>
						</div>					
					</div>
					<!-- End Page Header -->								
										
<div class="row">						
						<div class="col-lg-12">
							<div class="panel bk-bg-white">
								<div class="panel-heading bk-bg-primary">
									<h6><i class="fa fa-tags red"></i>清理缓存-<font color="#FF0000">除了首页其他不推荐清理</font></h6>
								</div>
								<div class="panel-body">
									<div class="wizard-type1">
									<div class="tab-content">

											<div class="tab-pane1">
												<div class="form-group">
												<div class="row">
													<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
													<label for="name-w1">网站首页缓存</label>
														<div class="input-group">
									<input id="s_shouye" class="form-control" name="s_shouye" type="text" size="40" value="<?php echo getRealSize(getDirSize('../cache/index'));?>" readonly="true"/>
													<span class="input-group-btn">
													<a href="cms_clear.php?clear=index"><button type="button" class="btn btn-success"  >清</button></a>
													</span>
												</div>
													</div>
													<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
													<label for="name-w1">清除视频列表缓存</label>
														<div class="input-group">
									<input id="s_shouye" class="form-control" name="s_shouye" type="text" size="40" value="<?php echo getRealSize(getDirSize('../cache/list'));?>" readonly="true"/>
													<span class="input-group-btn">
													<a href="cms_clear.php?clear=list"><button type="button" class="btn btn-success"  >清</button></a>
													</span>
												</div>
													</div>
													<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
													<label for="name-w1">清除影视排行缓存</label>
														<div class="input-group">
									<input id="s_paihang" class="form-control" name="s_paihang" type="text" size="40" value="<?php echo getRealSize(getDirSize('../cache/top'));?>" readonly="true"/>
													<span class="input-group-btn">
													<a href="cms_clear.php?clear=top"><button type="button" class="btn btn-success">清</button></a>
													</span>
												</div>
													</div>

													
													
												</div>
								

<div class="form-group">
												<div class="row">
												<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
													<label for="name-w1">清除影视播放缓存</label>
														<div class="input-group">
									<input id="s_paihang" class="form-control" name="s_paihang" type="text" size="40" value="<?php echo getRealSize(getDirSize('../cache/play'));?>" readonly="true"/>
													<span class="input-group-btn">
													<a href="cms_clear.php?clear=play"><button type="button" class="btn btn-success">清</button></a>
													</span>
												</div>
													</div>
													<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
													<label for="name-w1">清除猜你喜欢缓存</label>
														<div class="input-group">
									<input id="s_paihang" class="form-control" name="s_paihang" type="text" size="40" value="<?php echo getRealSize(getDirSize('../cache/like'));?>" readonly="true"/>
													<span class="input-group-btn">
													<a href="cms_clear.php?clear=like"><button type="button" class="btn btn-success">清</button></a>
													</span>
												</div>
													</div>
													<div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
													<label for="name-w1">清除幻灯缓存</label>
														<div class="input-group">
									<input id="s_paihang" class="form-control" name="s_paihang" type="text" size="40" value="<?php echo getRealSize(getDirSize('../cache/slide'));?>" readonly="true"/>
													<span class="input-group-btn">
													<a href="cms_clear.php?clear=slide"><button type="button" class="btn btn-success">清</button></a>
													</span>
												</div>
													</div>
												</div>
</div>
								
											
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					
				</div>
				<!-- End Main Page -->			
<?php include('inc_footer.php') ?>