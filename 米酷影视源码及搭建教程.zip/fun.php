<?php
include('system/inc.php');
include('template/'.$mkcms_bdyun.'/fun.php');
?>