<?php
include('system/inc.php');
include('system/pcon.php');
{include('template/'.$mkcms_bdyun.'/fuli.php');}?>