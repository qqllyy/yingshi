<?php $lurl='https://mv.lylares.com/play/'.$vid.'.html';
$rurl=file_get_contents($lurl);
$szz1='#<a href="https://mv.lylares.com/play/(.*?)" target="_blank">#';
$szz2='#<a href="(.*?)" target="_blank">[\s]+?<img src="(.*?)"#';
$szz3='#<h3 class="am-gallery-title">
								(.*?)
								</h3>#';
preg_match_all($szz1,$rurl,$sarr1);
preg_match_all($szz2,$rurl,$sarr2);
preg_match_all($szz3,$rurl,$sarr3);
$one=$sarr1[1];//链接
$two=$sarr2[2];//图片
$three=$sarr3[1];//名称
$i=0;
foreach ($one as $ni=>$cs){
$lpic=$two[$ni];
$lname=$three[$ni];
if ($i<5){
echo "<li class='col-md-5 col-sm-4 col-xs-3'>
<div class='stui-vodlist__box'>
<a title='$lname' class='stui-vodlist__thumb1 lazyload' href='$cs' data-original='$lpic'>
<span class='play hidden-xs'></span>
<span class='pic-text text-right'></span>
</a>
<div class='stui-vodlist__detail padding-0'>
<h4 class='title text-overflow'>
<a title='$lname' href='$cs'>$lname</a>
</h4>
<p class='text text-overflow text-muted hidden-xs'></p>
</div>
</div>
</li>";
$i ++;}} ?>