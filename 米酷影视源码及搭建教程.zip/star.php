<?php 
include('system/inc.php');
$mxq=$_GET['wd'];
$leixing=$_GET['tab'];
include('system/pcon.php');
{include('template/'.$mkcms_bdyun.'/star.php');}?>