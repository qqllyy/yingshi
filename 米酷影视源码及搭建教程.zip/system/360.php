<?php
$cat=$_GET['cat'];//类型
$year=intval($_GET['year']);//年份
if($year==0)$year='all';
$area=$_GET['area'];//地区
$act=$_GET['act'];//主演
$rank=$_GET['rank'];//火热
$pageno=intval($_GET['pageno']);
if($pageno==0){$pageno=1;}//页数
$wangzhi="http://www.360kan.com/$leixing/list.php?";
$wangzhii="cat=$cat&year=$year&area=$area&act=$act&rank=$rank&pageno=$pageno";
$flid2=$wangzhi.$wangzhii;
$hqym="http://www.360kan.com/$leixing/listajax?&$wangzhii";
mkdir('./cache');
mkdir('./cache/list');
$gxpd=time()-filemtime('./cache/list/'.md5($flid2));
if($gxpd>2*60*60){
$fcon=curl_file_get_contents($flid2);
file_put_contents('./cache/list/'.md5($flid2),gzdeflate($fcon));
}
$fcon=gzinflate(file_get_contents('./cache/list/'.md5($flid2)));
$gxpdd=time()-filemtime('./cache/list/'.md5($hqym));
if($gxpdd>72*60*60){
$fconn=curl_file_get_contents($hqym);
file_put_contents('./cache/list/'.md5($hqym),gzdeflate($fconn));
}
$fconn=gzinflate(file_get_contents('./cache/list/'.md5($hqym)));
$dataz=json_decode($fconn,TRUE);
$vname='#<span class="s1">(.*?)</span>#';
$fname='#<span class="s2">(.*?)</span>#';
$vlist='#<a class="js-tongjic" href="(.*?)">#';
$vstar='# <p class="star">(.*?)</p>#';
$vvlist='#<div class="s-tab-main">[\s\S]+?<div class="s-common-body">#';
$vimg='#<img src="(.*?)">#'; 
$bflist='#<a data-daochu(.*?) href="(.*?)" class="js-site-btn btn btn-play"></a>#';
$jishu='#<span class="hint">(.*?)</span>#'; 
$fufei='#<span class="pay">(.*?)</span>#'; 
$yuming='https://www.360kan.com'; 
preg_match_all($vname, $fcon,$xarr); 
preg_match_all($fname, $fcon,$xarrf); 
preg_match_all($vlist, $fcon,$xarr1); 
preg_match_all($vstar, $fcon,$xarr2); 
preg_match_all($vvlist, $fcon,$imglist);
$zcf=implode($glue, $imglist[0]);
preg_match_all($vimg, $zcf,$xarr3); 
preg_match_all($bflist, $fcon,$xarr4); 
preg_match_all($jishu, $fcon,$xarr5); 
preg_match_all($fufei, $fcon,$xarrff); 
$xname=$xarr[1];$lname=$xarrf[1];
$xlist=$xarr1[1];$xstar=$xarr2[1];
$ximg=$xarr3[1];$xbflist=$xarr4[1];
$xjishu=$xarr5[1];
$xfufei=$xarrff[1]; 
?>